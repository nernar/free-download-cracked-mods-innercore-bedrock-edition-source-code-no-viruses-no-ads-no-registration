IDRegistry.genItemID("DS");
IDRegistry.genItemID("SDSW");
IDRegistry.genItemID("SDHoe");
IDRegistry.genItemID("SDSH");
IDRegistry.genItemID("SDAX");
IDRegistry.genItemID("SDPI");



Item.createItem("DS", "§l§1Чистый Алмаз",{name: "DiamondSuper", meta:0},{isTech: false, stack:64});

Item.createItem("SDSW", "Меч из Чистого Алмаза", {name: "SDSworld", meta: 0}, {isTech: false, stack: 1});

Item.createItem("SDHoe", "Мотыга из Чистого Алмаза", {name: "SDHoe", meta: 0}, {isTech: false, stack: 1});

Item.createItem("SDSH", "Лопата из Чистого Алмаза", {name: "SDShovel", meta: 0}, {isTech: false, stack: 1});

Item.createItem("SDPI", "Кирка из Чистого Алмаза", {name: "SDPickaxe", metal: 0}, {isTech: false, stack: 1});

Item.createItem("SDAX", "Топор из Чистого алмаза", {name: "SDAxel", meta: 0}, {isTech: false, stack: 1});