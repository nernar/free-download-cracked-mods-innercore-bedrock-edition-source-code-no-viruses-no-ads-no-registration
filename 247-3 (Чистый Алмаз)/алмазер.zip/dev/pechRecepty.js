//кпафты печки
Recipes.addFurnace(173, ItemID.DS, 0);