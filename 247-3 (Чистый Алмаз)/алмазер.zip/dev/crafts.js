Recipes.addShaped({id:ItemID.SDB, count:1, data:0}, ['oao', 'oao'], ['o', ItemID.DS, 0]);

Recipes.addShaped({id:ItemID.SDH, count:1, data:0}, ['ooo', 'oao'], ['o', ItemID.DS, 0]);

Recipes.addShaped({id:ItemID.SDC, count:1, data:0}, ['oao', 'ooo', 'ooo'], ['o', ItemID.DS, 0]);

Recipes.addShaped({id:ItemID.SDL, count:1, data:0}, ['ooo', 'oao', 'oao'], ['o', ItemID.DS, 0]);