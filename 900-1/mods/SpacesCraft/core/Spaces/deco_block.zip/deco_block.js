IDRegistry.genBlockID("deco_block");
Block.createBlock("deco_block",[{name: "Deco Block", texture: [["Deco Block", 0]], inCreative: true} ]);
Translation.addTranslation("Deco Block",{
ru: "Декоративный-оловяный блок"
})